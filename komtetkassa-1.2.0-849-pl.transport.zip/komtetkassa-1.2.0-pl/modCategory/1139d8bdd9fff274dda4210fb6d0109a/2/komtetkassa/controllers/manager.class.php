<?php

class kkManagerController extends modExtraManagerController
{
    // public $k;

}