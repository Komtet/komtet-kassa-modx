<?php
require_once (dirname(__DIR__) . '/komtetorderfiscstatus.class.php');
class komtetOrderFiscStatus_mysql extends komtetOrderFiscStatus {}