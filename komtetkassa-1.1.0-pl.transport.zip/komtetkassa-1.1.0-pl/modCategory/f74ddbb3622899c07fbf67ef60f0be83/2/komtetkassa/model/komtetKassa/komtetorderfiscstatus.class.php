<?php
class komtetOrderFiscStatus extends xPDOSimpleObject {}